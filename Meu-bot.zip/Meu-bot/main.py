from keep_alive import keep_alive
import discord
from discord.ext import commands
import sqlite3
import os
from dotenv import load_dotenv

# Inicia o servidor web
keep_alive()

# Conectar ao banco de dados SQLite
conn = sqlite3.connect("bot_database.db")
c = conn.cursor()

# Criar a tabela para armazenar status se não existir
c.execute('''CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    hp INTEGER,
    mp INTEGER,
    hp_base INTEGER,
    mp_base INTEGER
)''')
conn.commit()

# Configuração do bot
intents = discord.Intents.default()
intents.messages = True
intents.guilds = True
intents.message_content = True
client = commands.Bot(command_prefix="!", intents=intents)

# Função para obter status do usuário no banco de dados
def get_user_status(user_id):
    c.execute("SELECT hp, mp, hp_base, mp_base FROM users WHERE user_id = ?", (user_id,))
    result = c.fetchone()
    if result:
        return {"hp": result[0], "mp": result[1], "hp_base": result[2], "mp_base": result[3]}
    else:
        return None

# Função para definir ou atualizar status do usuário
def set_user_status(user_id, hp, mp, hp_base, mp_base):
    if get_user_status(user_id):
        c.execute("UPDATE users SET hp=?, mp=?, hp_base=?, mp_base=? WHERE user_id=?",
                  (hp, mp, hp_base, mp_base, user_id))
    else:
        c.execute("INSERT INTO users (user_id, hp, mp, hp_base, mp_base) VALUES (?, ?, ?, ?, ?)",
                  (user_id, hp, mp, hp_base, mp_base))
    conn.commit()

# Função para criar barra de status visual
def create_bar(current, maximum, length=10):
    fill = "█"  # Bloco preenchido
    empty = "░"  # Bloco vazio
    fill_count = round((current / maximum) * length)
    return fill * fill_count + empty * (length - fill_count)

# Função para selecionar o emote de HP
def get_hp_emote(hp, hp_base):
    hp_percent = (hp / hp_base) * 100
    if hp_percent == 100:
        return ":sparkling_heart:"
    elif hp_percent >= 20:
        return ":heart:"
    elif hp_percent >= 1:
        return ":broken_heart:"
    else:
        return ":skull:"

# Função para selecionar o emote de MP
def get_mp_emote(mp, mp_base):
    mp_percent = (mp / mp_base) * 100
    if mp_percent == 100:
        return ":diamond_shape_with_a_dot_inside:"
    elif mp_percent >= 20:
        return ":large_blue_diamond:"
    elif mp_percent >= 1:
        return ":small_blue_diamond:"
    else:
        return ":white_small_square:"

# Evento de início de conexão
@client.event
async def on_ready():
    print(f'Bot conectado como {client.user}')

# Comando para verificar o status de HP e MP de um usuário
@client.command()
async def status(ctx, user: discord.User = None):
    if user is None:
        user = ctx.author

    user_id = str(user.id)
    status = get_user_status(user_id)

    if status is None:
        set_user_status(user_id, 25, 25, 25, 25)
        status = {"hp": 25, "mp": 25, "hp_base": 25, "mp_base": 25}

    hp_emote = get_hp_emote(status['hp'], status['hp_base'])
    mp_emote = get_mp_emote(status['mp'], status['mp_base'])
    hp_bar = create_bar(status['hp'], status['hp_base'])
    mp_bar = create_bar(status['mp'], status['mp_base'])

    embed = discord.Embed(title=f"🎭 Status de {user.name}", color=discord.Color.purple())
    embed.add_field(name=f"{hp_emote} HP", value=f"{status['hp']}/{status['hp_base']} \n`{hp_bar}`", inline=False)
    embed.add_field(name=f"{mp_emote} MP", value=f"{status['mp']}/{status['mp_base']} \n`{mp_bar}`", inline=False)
    embed.set_thumbnail(url=user.avatar.url if user.avatar else None)

    await ctx.send(embed=embed)

# Comando para alterar HP
@client.command()
async def hp(ctx, value: int, user: discord.User = None):
    if user is None:
        user = ctx.author
    user_id = str(user.id)
    status = get_user_status(user_id)

    if status is None:
        set_user_status(user_id, 25, 25, 25, 25)
        status = {"hp": 25, "mp": 25, "hp_base": 25, "mp_base": 25}

    new_hp = max(0, min(status['hp'] + value, status['hp_base']))
    set_user_status(user_id, new_hp, status['mp'], status['hp_base'], status['mp_base'])
    await ctx.send(f"{user.name}'s HP foi alterado! HP: {new_hp}")

# Comando para alterar MP
@client.command()
async def mp(ctx, value: int, user: discord.User = None):
    if user is None:
        user = ctx.author
    user_id = str(user.id)
    status = get_user_status(user_id)

    if status is None:
        set_user_status(user_id, 25, 25, 25, 25)
        status = {"hp": 25, "mp": 25, "hp_base": 25, "mp_base": 25}

    new_mp = max(0, min(status['mp'] + value, status['mp_base']))
    set_user_status(user_id, status['hp'], new_mp, status['hp_base'], status['mp_base'])
    await ctx.send(f"{user.name}'s MP foi alterado! MP: {new_mp}")

# Comando para definir valores base
@client.command()
async def set_base(ctx, stat: str, value: int, user: discord.User = None):
    if user is None:
        user = ctx.author
    user_id = str(user.id)
    status = get_user_status(user_id)

    if status is None:
        set_user_status(user_id, 25, 25, 25, 25)
        status = {"hp": 25, "mp": 25, "hp_base": 25, "mp_base": 25}

    if stat.lower() == "hp":
        set_user_status(user_id, min(status['hp'], value), status['mp'], value, status['mp_base'])
        await ctx.send(f"{user.name}'s HP base foi definido para {value}.")
    elif stat.lower() == "mp":
        set_user_status(user_id, status['hp'], min(status['mp'], value), status['hp_base'], value)
        await ctx.send(f"{user.name}'s MP base foi definido para {value}.")
    else:
        await ctx.send("Por favor, use 'hp' ou 'mp' para definir o valor base.")

# Carregar o token do bot
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
client.run(TOKEN)